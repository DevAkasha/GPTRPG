﻿using UnityEngine;

//소재철 튜터님 프레임워크 스크립트
public class BaseData : ScriptableObject
{
    public string key;
}